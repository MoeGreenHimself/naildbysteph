import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { ChevronLeft, Plus, Edit2, Trash2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Admin() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("appointments");

  // Fetch data from backend
  const { data: appointments = [] } = trpc.appointments.list.useQuery();
  const { data: availability = [] } = trpc.availability.list.useQuery();
  const { data: allContent = [] } = trpc.content.getAll.useQuery();

  // Mutations
  const updateAppointmentMutation = trpc.appointments.update.useMutation();
  const upsertContentMutation = trpc.content.upsert.useMutation();

  const [aboutText, setAboutText] = useState("");
  const [contactText, setContactText] = useState("");

  // Load content from backend
  const handleSaveAbout = async () => {
    try {
      await upsertContentMutation.mutateAsync({
        key: "about_text",
        value: aboutText,
      });
      toast.success("About section updated!");
    } catch (error) {
      toast.error("Failed to update about section");
    }
  };

  const handleSaveContact = async () => {
    try {
      await upsertContentMutation.mutateAsync({
        key: "contact_text",
        value: contactText,
      });
      toast.success("Contact section updated!");
    } catch (error) {
      toast.error("Failed to update contact section");
    }
  };

  // Check if user is admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="p-8 text-center">
          <p className="text-gray-700 mb-4">You do not have permission to access this page.</p>
          <Link href="/">
            <Button className="bg-pink-600 hover:bg-pink-700">Go Home</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          {["appointments", "availability", "content"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-semibold transition ${
                activeTab === tab
                  ? "text-pink-600 border-b-2 border-pink-600"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Appointments Tab */}
        {activeTab === "appointments" && (
          <Card className="p-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Manage Appointments</h2>
              <Button className="bg-pink-600 hover:bg-pink-700 gap-2">
                <Plus className="w-4 h-4" />
                New Appointment
              </Button>
            </div>

            {appointments.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No appointments yet</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Name</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Date</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Time</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {appointments.map((apt: any) => (
                      <tr key={apt.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="px-4 py-3 text-gray-900">{apt.customerName}</td>
                        <td className="px-4 py-3 text-gray-700">{new Date(apt.appointmentDate).toLocaleDateString()}</td>
                        <td className="px-4 py-3 text-gray-700">{apt.appointmentTime}</td>
                        <td className="px-4 py-3">
                          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            apt.status === "confirmed"
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}>
                            {apt.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 flex gap-2">
                          <Button variant="ghost" size="sm" className="gap-1">
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="gap-1 text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}

        {/* Availability Tab */}
        {activeTab === "availability" && (
          <Card className="p-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Manage Availability</h2>
              <Button className="bg-pink-600 hover:bg-pink-700 gap-2">
                <Plus className="w-4 h-4" />
                Add Slot
              </Button>
            </div>

            {availability.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No availability slots configured</p>
            ) : (
              <div className="space-y-4">
                {availability.map((slot: any) => {
                  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                  return (
                    <div key={slot.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">{dayNames[slot.dayOfWeek]}</p>
                        <p className="text-sm text-gray-600">{slot.startTime} - {slot.endTime}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm" className="gap-1">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="gap-1 text-red-600 hover:text-red-700">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        )}

        {/* Content Tab */}
        {activeTab === "content" && (
          <div className="space-y-8">
            {/* About Text */}
            <Card className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">About Section</h2>
              <div>
                <Label htmlFor="about">About Text</Label>
                <textarea
                  id="about"
                  value={aboutText}
                  onChange={(e) => setAboutText(e.target.value)}
                  rows={6}
                  className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600"
                />
              </div>
              <Button onClick={handleSaveAbout} className="mt-4 bg-pink-600 hover:bg-pink-700">Save Changes</Button>
            </Card>

            {/* Contact Text */}
            <Card className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Contact Section</h2>
              <div>
                <Label htmlFor="contact">Contact Information</Label>
                <textarea
                  id="contact"
                  value={contactText}
                  onChange={(e) => setContactText(e.target.value)}
                  rows={4}
                  className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600"
                />
              </div>
              <Button onClick={handleSaveContact} className="mt-4 bg-pink-600 hover:bg-pink-700">Save Changes</Button>
            </Card>

            {/* Portfolio Management */}
            <Card className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Portfolio Images</h2>
                <Button className="bg-pink-600 hover:bg-pink-700 gap-2">
                  <Plus className="w-4 h-4" />
                  Add Image
                </Button>
              </div>
              <p className="text-gray-600">Portfolio image management will be available here.</p>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
