import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { ChevronLeft, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function BookAppointment() {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    appointmentDate: "",
    appointmentTime: "",
    paymentMethod: "",
  });

  // Fetch availability slots
  const { data: availabilitySlots = [] } = trpc.availability.list.useQuery();

  // Generate available times based on slots
  const availableTimes = [
    "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00"
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNext = () => {
    if (step === 1) {
      if (!formData.customerName || !formData.customerEmail || !formData.customerPhone) {
        toast.error("Please fill in all fields");
        return;
      }
    }
    if (step === 2) {
      if (!formData.appointmentDate || !formData.appointmentTime) {
        toast.error("Please select a date and time");
        return;
      }
    }
    if (step < 3) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  // Create mutations
  const createAppointmentMutation = trpc.appointments.create.useMutation();
  const createPaymentMutation = trpc.payments.create.useMutation();

  const handleSubmit = async () => {
    if (!formData.paymentMethod) {
      toast.error("Please select a payment method");
      return;
    }

    setIsSubmitting(true);
    try {
      // Create appointment
      const appointmentDate = new Date(formData.appointmentDate);
      
      const appointment = await createAppointmentMutation.mutateAsync({
        customerName: formData.customerName,
        customerEmail: formData.customerEmail,
        customerPhone: formData.customerPhone,
        appointmentDate: appointmentDate,
        appointmentTime: formData.appointmentTime,
        status: "pending" as const,
        depositPaid: 0,
        depositAmount: 2500,
        paymentMethod: formData.paymentMethod,
      });

      // Create payment record
      // Note: In a real app, we would get the appointment ID from the response
      await createPaymentMutation.mutateAsync({
        appointmentId: 1,
        amount: 2500,
        paymentMethod: formData.paymentMethod as "cash_app" | "venmo" | "paypal",
        status: "pending" as const,
      });

      toast.success("Appointment booked! Check your email for confirmation.");
      
      // Reset form and redirect
      setTimeout(() => {
        setFormData({
          customerName: "",
          customerEmail: "",
          customerPhone: "",
          appointmentDate: "",
          appointmentTime: "",
          paymentMethod: "",
        });
        window.location.href = "/";
      }, 2000);
    } catch (error) {
      console.error("Booking error:", error);
      toast.error("Failed to book appointment. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Book Your Appointment</h1>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Progress Indicator */}
        <div className="mb-8 flex justify-between items-center">
          {[1, 2, 3].map((num) => (
            <div key={num} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                num <= step ? "bg-pink-600 text-white" : "bg-gray-300 text-gray-600"
              }`}>
                {num}
              </div>
              {num < 3 && (
                <div className={`flex-1 h-1 mx-2 ${num < step ? "bg-pink-600" : "bg-gray-300"}`}></div>
              )}
            </div>
          ))}
        </div>

        {/* Step 1: Personal Information */}
        {step === 1 && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Information</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleInputChange}
                  placeholder="Enter your full name"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  name="customerEmail"
                  type="email"
                  value={formData.customerEmail}
                  onChange={handleInputChange}
                  placeholder="Enter your email"
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  name="customerPhone"
                  type="tel"
                  value={formData.customerPhone}
                  onChange={handleInputChange}
                  placeholder="Enter your phone number"
                  className="mt-2"
                />
              </div>
            </div>
            <div className="flex justify-end gap-4 mt-8">
              <Button variant="outline" onClick={handleBack} disabled>
                Back
              </Button>
              <Button onClick={handleNext} className="bg-pink-600 hover:bg-pink-700">
                Next
              </Button>
            </div>
          </Card>
        )}

        {/* Step 2: Date & Time Selection */}
        {step === 2 && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Select Date & Time</h2>
            <div className="space-y-6">
              <div>
                <Label htmlFor="date">Appointment Date *</Label>
                <Input
                  id="date"
                  name="appointmentDate"
                  type="date"
                  value={formData.appointmentDate}
                  onChange={handleInputChange}
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Appointment Time *</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {availableTimes.map((time) => (
                    <button
                      key={time}
                      onClick={() => setFormData(prev => ({ ...prev, appointmentTime: time }))}
                      className={`p-3 rounded border-2 transition ${
                        formData.appointmentTime === time
                          ? "border-pink-600 bg-pink-50"
                          : "border-gray-300 hover:border-pink-600"
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between gap-4 mt-8">
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleNext} className="bg-pink-600 hover:bg-pink-700">
                Next
              </Button>
            </div>
          </Card>
        )}

        {/* Step 3: Payment Method */}
        {step === 3 && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Payment Method</h2>
            <p className="text-gray-700 mb-6">
              A $25 deposit is required to confirm your appointment.
            </p>
            <div className="space-y-3 mb-8">
              {[
                { id: "cash_app", label: "Cash App", desc: "$25.00 via Cash App" },
                { id: "venmo", label: "Venmo", desc: "$25.00 via Venmo" },
                { id: "paypal", label: "PayPal", desc: "$25.00 via PayPal" },
              ].map((method) => (
                <button
                  key={method.id}
                  onClick={() => setFormData(prev => ({ ...prev, paymentMethod: method.id }))}
                  className={`w-full p-4 rounded border-2 text-left transition ${
                    formData.paymentMethod === method.id
                      ? "border-pink-600 bg-pink-50"
                      : "border-gray-300 hover:border-pink-600"
                  }`}
                >
                  <div className="font-semibold text-gray-900">{method.label}</div>
                  <div className="text-sm text-gray-600">{method.desc}</div>
                </button>
              ))}
            </div>

            {/* Cancellation Policy */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
              <h3 className="font-semibold text-blue-900 mb-2">Cancellation Policy</h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Cancellations or rescheduling within 24 hours can be transferred to new appointment times</li>
                <li>• Cancellations with less than 24 hours notice are forfeited</li>
              </ul>
            </div>

            <div className="flex justify-between gap-4">
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button 
                onClick={handleSubmit} 
                className="bg-pink-600 hover:bg-pink-700"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  "Confirm Booking"
                )}
              </Button>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}
