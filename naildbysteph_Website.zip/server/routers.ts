import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getAppointments,
  getAppointmentById,
  createAppointment,
  updateAppointment,
  getAvailabilitySlots,
  createAvailabilitySlot,
  updateAvailabilitySlot,
  getPortfolioImages,
  createPortfolioImage,
  updatePortfolioImage,
  deletePortfolioImage,
  getSiteContent,
  getAllSiteContent,
  upsertSiteContent,
  createPayment,
  getPaymentByAppointmentId,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Appointments router
  appointments: router({
    list: publicProcedure.query(async () => {
      return await getAppointments();
    }),
    getById: publicProcedure.input((val: unknown) => {
      if (typeof val === "number") return val;
      throw new Error("Invalid input");
    }).query(async ({ input }) => {
      return await getAppointmentById(input);
    }),
    create: publicProcedure.input((val: unknown) => val as any).mutation(async ({ input }) => {
      return await createAppointment(input);
    }),
    update: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const { id, ...data } = input;
      return await updateAppointment(id, data);
    }),
  }),

  // Availability router
  availability: router({
    list: publicProcedure.query(async () => {
      return await getAvailabilitySlots();
    }),
    create: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      return await createAvailabilitySlot(input);
    }),
    update: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const { id, ...data } = input;
      return await updateAvailabilitySlot(id, data);
    }),
  }),

  // Portfolio router
  portfolio: router({
    list: publicProcedure.query(async () => {
      return await getPortfolioImages();
    }),
    create: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      return await createPortfolioImage(input);
    }),
    update: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const { id, ...data } = input;
      return await updatePortfolioImage(id, data);
    }),
    delete: protectedProcedure.input((val: unknown) => {
      if (typeof val === "number") return val;
      throw new Error("Invalid input");
    }).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      return await deletePortfolioImage(input);
    }),
  }),

  // Site content router
  content: router({
    get: publicProcedure.input((val: unknown) => {
      if (typeof val === "string") return val;
      throw new Error("Invalid input");
    }).query(async ({ input }) => {
      return await getSiteContent(input);
    }),
    getAll: publicProcedure.query(async () => {
      return await getAllSiteContent();
    }),
    upsert: protectedProcedure.input((val: unknown) => val as any).mutation(async ({ input, ctx }: any) => {
      if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
      const { key, value } = input;
      return await upsertSiteContent(key, value);
    }),
  }),

  // Payments router
  payments: router({
    create: publicProcedure.input((val: unknown) => val as any).mutation(async ({ input }) => {
      return await createPayment(input);
    }),
    getByAppointmentId: publicProcedure.input((val: unknown) => {
      if (typeof val === "number") return val;
      throw new Error("Invalid input");
    }).query(async ({ input }) => {
      return await getPaymentByAppointmentId(input);
    }),
  }),
});

export type AppRouter = typeof appRouter;
